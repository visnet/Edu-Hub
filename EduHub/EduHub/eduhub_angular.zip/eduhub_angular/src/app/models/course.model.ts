export interface Course {
  CourseId?: number;
  Title: string;
  Description: string;
  CourseStartDate: string;
  CourseEndDate: string;
  Category: string;
  Level: string;
}
